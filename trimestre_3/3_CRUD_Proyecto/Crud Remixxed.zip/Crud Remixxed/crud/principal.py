from BD.conexion import DAO
import funciones


def menuPrincipal():
    continuar = True
    while(continuar):
        opcionCorrecta = False
        while(not opcionCorrecta):
            print("==================== REMIXXED PLAYLIST ====================")
            print("1.- Listar playlist")
            print("2.- Registrar playlist")
            print("3.- Actualizar playlist")
            print("4.- Eliminar playlist")
            print("5.- Salir")
            print("========================================================")
            opcion = int(input("Seleccione una opción: "))

            if opcion < 1 or opcion > 5:
                print("Opción incorrecta, ingrese nuevamente...")
            elif opcion == 5:
                continuar = False
                print("¡Gracias por usar este sistema!")
                break
            else:
                opcionCorrecta = True
                ejecutarOpcion(opcion)


def ejecutarOpcion(opcion):
    dao = DAO()

    if opcion == 1:
        try:
            playlist = dao.listarplaylist()
            if len(playlist) > 0:
                funciones.listarplaylist(playlist)
            else:
                print("No se encontraron playlist...")
        except:
            print("Ocurrió un error...")
    elif opcion == 2:
        playlist = funciones.pedirDatosRegistro()
        try:
            dao.registrarplaylist(playlist)
        except:
            print("Ocurrió un error...")
    elif opcion == 3:
        try:
            playlist = dao.listarplaylist()
            if len(playlist) > 0:
                curso = funciones.pedirDatosActualizacion(playlist)
                if curso:
                    dao.actualizarplaylist(playlist)
                else:
                    print("Código de playlist a actualizar no encontrado :( ...\n")
            else:
                print("No se encontraron playlist...")
        except:
            print("Ocurrió un error...")
    elif opcion == 4:
        try:
            playlist = dao.listarplaylist()
            if len(playlist) > 0:
                codigoEliminar = funciones.pedirDatosEliminacion(playlist)
                if not(codigoEliminar == ""):
                    dao.eliminarplaylist(codigoEliminar)
                else:
                    print("Código de playlist no encontrado...\n")
            else:
                print("No se encontraron playlist...")
        except:
            print("Ocurrió un error...")
    else:
        print("Opción no válida...")


menuPrincipal()
