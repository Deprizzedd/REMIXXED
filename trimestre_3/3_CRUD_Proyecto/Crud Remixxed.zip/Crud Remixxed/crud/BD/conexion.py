import mysql.connector
from mysql.connector import Error


class DAO():

    def __init__(self):
        try:
            self.conexion = mysql.connector.connect(
                host='localhost',
                port=3306,
                user='root',
                password='Diegolo12*',
                db='Remixxed01'
            )
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))

    def listarplaylist(self):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                cursor.execute("SELECT * FROM playlist ORDER BY nombre ASC")
                resultados = cursor.fetchall()
                return resultados
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def registrarplaylist(self, playlist):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "INSERT INTO playlist (codigo, nombre, canciones) VALUES ('{0}', '{1}', {2})"
                cursor.execute(sql.format(playlist[0], playlist[1], playlist[2]))
                self.conexion.commit()
                print("¡playlist registrado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def actualizarCurso(self, playlist):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "UPDATE playlist SET nombre = '{0}', canciones = {1} WHERE codigo = '{2}'"
                cursor.execute(sql.format(playlist[1], playlist[2], playlist[0]))
                self.conexion.commit()
                print("¡playlist actualizado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

    def eliminarplaylist(self, codigoplaylistEliminar):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                sql = "DELETE FROM playlist WHERE codigo = '{0}'"
                cursor.execute(sql.format(codigoplaylistEliminar))
                self.conexion.commit()
                print("¡playlist eliminado!\n")
            except Error as ex:
                print("Error al intentar la conexión: {0}".format(ex))

