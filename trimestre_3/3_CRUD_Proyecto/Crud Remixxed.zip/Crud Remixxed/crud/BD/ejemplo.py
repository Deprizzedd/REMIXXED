import mysql.connector
from mysql.connector import Error


class DAO():

    def __init__(self):
        try:
            self.conexion = mysql.connector.connect(
                host='localhost',
                port=3306,
                user='root',
                password='Diegolo12*',
                db='Remixxed01'
            )



def listarReproducciones(self):
    if self.conexion.is_connected():
        try:
            cursor = self.conexion.cursor()
            cursor.execute("SELECT * FROM lista_reproduccion ORDER BY nombre ASC")
            resultados = cursor.fetchall()
            return resultados
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))

def registrarReproduccion(self, reproduccion):
    if self.conexion.is_connected():
        try:
            cursor = self.conexion.cursor()
            sql = "INSERT INTO lista_reproduccion (nombre, artista, duracion) VALUES ('{0}', '{1}', {2})"
            cursor.execute(sql.format(reproduccion[0], reproduccion[1], reproduccion[2]))
            self.conexion.commit()
            print("¡Reproducción registrada!\n")
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))

def actualizarReproduccion(self, reproduccion):
    if self.conexion.is_connected():
        try:
            cursor = self.conexion.cursor()
            sql = "UPDATE lista_reproduccion SET nombre = '{0}', artista = '{1}', duracion = {2} WHERE id = {3}"
            cursor.execute(sql.format(reproduccion[1], reproduccion[2], reproduccion[3], reproduccion[0]))
            self.conexion.commit()
            print("¡Reproducción actualizada!\n")
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))

def eliminarReproduccion(self, idReproduccionEliminar):
    if self.conexion.is_connected():
        try:
            cursor = self.conexion.cursor()
            sql = "DELETE FROM lista_reproduccion WHERE id = {0}"
            cursor.execute(sql.format(idReproduccionEliminar))
            self.conexion.commit()
            print("¡Reproducción eliminada!\n")
        except Error as ex:
            print("Error al intentar la conexión: {0}".format(ex))
