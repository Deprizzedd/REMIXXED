def listarplaylist(playlist):
    print("\nplaylist: \n")
    contador = 1
    for cur in playlist:
        datos = "{0}. Código: {1} | Nombre: {2} ({3} canciones)"
        print(datos.format(contador, cur[0], cur[1], cur[2]))
        contador = contador + 1
    print(" ")


def pedirDatosRegistro():
    codigoCorrecto = False
    while(not codigoCorrecto):
        codigo = input("Ingrese código: ")
        if len(codigo) == 6:
            codigoCorrecto = True
        else:
            print("Código incorrecto: Debe tener 6 dígitos.")

    nombre = input("Ingrese nombre: ")

    cancionesCorrecto = False
    while(not cancionesCorrecto):
        canciones = input("Ingrese canciones: ")
        if canciones.isnumeric():
            if (int(canciones) > 0):
                cancionesCorrecto = True
                canciones = int(canciones)
            else:
                print("Las canciones deben ser mayor a 0.")
        else:
            print("Canciones incorrectas: Debe ser un número únicamente.")

    playlist = (codigo, nombre, canciones)
    return playlist

def pedirDatosActualizacion(playlist):
    listarplaylist(playlist)
    existeCodigo = False
    codigoEditar = input("Ingrese el código de la playlist a editar: ")
    for cur in playlist:
        if cur[0] == codigoEditar:
            existeCodigo = True
            break

    if existeCodigo:
        nombre = input("Ingrese nombre a modificar: ")

        playlistCorrecto = False
        while(not playlistCorrecto):
            canciones = input("Ingrese canciones a modificar: ")
            if canciones.isnumeric():
                if (int(canciones) > 0):
                    cancionesCorrecto = True
                    canciones = int(canciones)
                else:
                    print("Las canciones deben ser mayor a 0.")
            else:
                print("Canciones incorrectas: Debe ser un número únicamente.")

        playlist = (codigoEditar, nombre, canciones)
    else:
        playlist = None

    return playlist


def pedirDatosEliminacion(playlist):
    listarplaylist(playlist)
    existeCodigo = False
    codigoEliminar = input("Ingrese el código de la playlist a eliminar: ")
    for cur in playlist:
        if cur[0] == codigoEliminar:
            existeCodigo = True
            break

    if not existeCodigo:
        codigoEliminar = ""

    return codigoEliminar
